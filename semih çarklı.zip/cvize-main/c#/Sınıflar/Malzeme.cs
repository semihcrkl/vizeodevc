﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YemekTarifi.Sınıflar
{
    public class Malzeme
    {
        public string malzemeAdi;
    }
}
